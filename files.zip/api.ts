import type { Room } from "@/types/room";

// TODO: ganti dengan axios.get("/rooms") dari lib/axios.ts setelah endpoint siap.
// Bentuk return (Promise<Room[]>) dibuat sama supaya pemanggil tidak perlu diubah.
const placeholderRooms: Room[] = [
  { id: 1, slug: "aurum-boardroom-suite", name: "The Aurum Boardroom & Suite", buildingName: "Building A", typeName: "Meeting room", capacity: 20, price: 2500000, priceUnit: "daily", coverImage: "/images/rooms/boardroom.jpg" },
  { id: 2, slug: "open-coworking-floor", name: "Open Coworking Floor", buildingName: "Building A", typeName: "Coworking", capacity: 40, price: 1800000, priceUnit: "monthly", coverImage: "/images/rooms/coworking.jpg" },
  { id: 3, slug: "executive-private-office", name: "Executive Private Office", buildingName: "Building B", typeName: "Private office", capacity: 8, price: 15000000, priceUnit: "monthly", coverImage: "/images/rooms/private-office.jpg" },
  { id: 4, slug: "skyline-event-space", name: "Skyline Event Space", buildingName: "Building B", typeName: "Event space", capacity: 120, price: 9000000, priceUnit: "daily", coverImage: "/images/rooms/event-space.jpg" },
];

export async function fetchRooms(): Promise<Room[]> {
  return placeholderRooms;
}
