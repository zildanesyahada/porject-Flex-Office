import { useEffect, useState, type FormEvent } from "react";
import { Link, useNavigate } from "react-router-dom";
import { CalendarCheck, ShieldCheck, Zap } from "lucide-react";
import { Button, Container, Input, Select } from "@/components/ui";
import { RoomCard } from "@/components/shared/RoomCard";
import { fetchRooms } from "@/features/rooms/api";
import type { Room } from "@/types/room";

function Hero() {
  const stats = [
    { value: "2", label: "Buildings" },
    { value: "5", label: "Room types" },
  ];

  return (
    <section
      className="relative bg-navy bg-cover bg-center"
      style={{ backgroundImage: "url(/images/hero.jpg)" }}
    >
      <div className="absolute inset-0 bg-navy/75" />
      <Container className="relative grid grid-cols-[1.4fr_1fr] items-center gap-12 py-28">
        <div className="flex max-w-xl flex-col gap-6 text-white">
          <h1 className="text-[36px] font-bold leading-[1.2]">
            One Platform, Workspace You Can Trust
          </h1>
          <p className="text-white/80">
            Find, book, and pay for meeting rooms, coworking spaces, and private offices in two
            buildings. Your booking is confirmed the moment payment succeeds.
          </p>
          <div className="flex gap-3">
            <Link to="/rooms"><Button>Browse rooms</Button></Link>
            <Link to="/register"><Button variant="secondary">Create account</Button></Link>
          </div>
        </div>

        <div className="ml-auto flex gap-8 rounded-xl bg-surface p-6 shadow-pop">
          {stats.map((s) => (
            <div key={s.label}>
              <p className="text-[28px] font-bold text-primary">{s.value}</p>
              <p className="text-[13px] text-text-secondary">{s.label}</p>
            </div>
          ))}
        </div>
      </Container>
    </section>
  );
}

function PopularWorkspaces({ rooms }: { rooms: Room[] }) {
  const [featured, ...others] = rooms;
  if (!featured) return null;

  return (
    <section className="py-16">
      <Container>
        <h2 className="text-[22px] font-semibold">Popular workspaces</h2>
        <p className="mb-8 text-text-secondary">Rooms our customers book most often.</p>
        <div className="grid h-[420px] grid-cols-[2fr_1fr] gap-4">
          <RoomCard room={featured} variant="overlay" className="h-full" />
          <div className="grid grid-rows-2 gap-4">
            {others.slice(0, 2).map((room) => (
              <RoomCard key={room.id} room={room} variant="overlay" className="h-full" />
            ))}
          </div>
        </div>
      </Container>
    </section>
  );
}

function WhyFlexOffice() {
  const points = [
    { icon: CalendarCheck, title: "Live availability", text: "See which dates are open before you book." },
    { icon: Zap, title: "Instant confirmation", text: "Your booking is confirmed right after payment." },
    { icon: ShieldCheck, title: "Clear cancellation policy", text: "Free changes and cancellation up to 48 hours before." },
  ];

  return (
    <section className="bg-navy text-white">
      <Container className="grid grid-cols-2 items-center gap-16 py-20">
        <div className="flex flex-col gap-6">
          <h2 className="text-[28px] font-bold">Why FlexOffice</h2>
          <p className="text-white/80">
            One place to compare rooms across buildings, pay with QRIS, and keep every invoice.
          </p>
          <ul className="flex flex-col gap-5">
            {points.map(({ icon: Icon, title, text }) => (
              <li key={title} className="flex gap-4">
                <span className="flex size-10 shrink-0 items-center justify-center rounded-lg bg-white/10">
                  <Icon className="size-5" aria-hidden />
                </span>
                <div>
                  <h3 className="font-semibold">{title}</h3>
                  <p className="text-[13px] text-white/70">{text}</p>
                </div>
              </li>
            ))}
          </ul>
        </div>
        <div
          className="h-[360px] rounded-xl bg-white/5 bg-cover bg-center"
          style={{ backgroundImage: "url(/images/why.jpg)" }}
          role="img"
          aria-label="People working together in a meeting room"
        />
      </Container>
    </section>
  );
}

function SearchBar() {
  const navigate = useNavigate();
  const [filters, setFilters] = useState({ building: "", type: "", capacity_min: "", date: "" });

  const bind = (key: keyof typeof filters) => ({
    value: filters[key],
    onChange: (e: { target: { value: string } }) =>
      setFilters((prev) => ({ ...prev, [key]: e.target.value })),
  });

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    const params = new URLSearchParams(Object.entries(filters).filter(([, v]) => v));
    navigate(`/rooms?${params.toString()}`);
  }

  return (
    <form
      onSubmit={handleSubmit}
      className="mb-10 grid grid-cols-[repeat(4,1fr)_auto] items-end gap-4 rounded-xl bg-surface p-5 shadow-card"
    >
      <Select label="Building" {...bind("building")}>
        <option value="">All buildings</option>
        <option value="1">Building A</option>
        <option value="2">Building B</option>
      </Select>
      <Select label="Room type" {...bind("type")}>
        <option value="">All types</option>
        <option value="meeting-room">Meeting room</option>
        <option value="coworking">Coworking</option>
        <option value="workspace">Workspace</option>
        <option value="private-office">Private office</option>
        <option value="event-space">Event space</option>
      </Select>
      <Input label="Min. capacity" type="number" min={1} placeholder="e.g. 10" {...bind("capacity_min")} />
      <Input label="Start date" type="date" {...bind("date")} />
      <Button type="submit">Search rooms</Button>
    </form>
  );
}

function FindRightSpace({ rooms }: { rooms: Room[] }) {
  return (
    <section className="pb-16">
      <Container>
        <h2 className="text-[22px] font-semibold">Find the right space for your needs</h2>
        <p className="mb-8 text-text-secondary">Filter by building, type, capacity, and date.</p>
        <SearchBar />
        <div className="grid grid-cols-4 gap-4">
          {rooms.map((room) => (
            <RoomCard key={room.id} room={room} />
          ))}
        </div>
      </Container>
    </section>
  );
}

function CtaBanner() {
  return (
    <section className="pb-20">
      <Container>
        <div className="flex flex-col items-center gap-5 rounded-2xl bg-navy px-8 py-14 text-center text-white">
          <h2 className="text-[28px] font-bold">Ready to find your next workspace?</h2>
          <p className="max-w-lg text-white/80">
            Create an account, verify your email once, and book your first room today.
          </p>
          <Link to="/rooms"><Button>Browse all rooms</Button></Link>
        </div>
      </Container>
    </section>
  );
}

export default function LandingPage() {
  const [rooms, setRooms] = useState<Room[]>([]);

  useEffect(() => {
    fetchRooms().then(setRooms);
  }, []);

  return (
    <>
      <Hero />
      <PopularWorkspaces rooms={rooms} />
      <WhyFlexOffice />
      <FindRightSpace rooms={rooms} />
      <CtaBanner />
    </>
  );
}
