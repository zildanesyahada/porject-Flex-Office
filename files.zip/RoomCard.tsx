import { Link } from "react-router-dom";
import { Users } from "lucide-react";
import { Button, Card } from "@/components/ui";
import { cn, formatCurrency } from "@/lib/utils";
import type { PriceUnit, Room } from "@/types/room";

const unitLabel: Record<PriceUnit, string> = {
  daily: "/ day",
  monthly: "/ month",
  yearly: "/ year",
};

function RoomImage({ room, className }: { room: Room; className?: string }) {
  return (
    <img
      src={room.coverImage}
      alt={room.name}
      className={cn("size-full object-cover", className)}
      onError={(e) => (e.currentTarget.style.display = "none")}
    />
  );
}

interface RoomCardProps {
  room: Room;
  variant?: "default" | "overlay";
  className?: string;
}

export function RoomCard({ room, variant = "default", className }: RoomCardProps) {
  const price = `${formatCurrency(room.price)} ${unitLabel[room.priceUnit]}`;

  if (variant === "overlay") {
    return (
      <Link
        to={`/rooms/${room.slug}`}
        className={cn("group relative block overflow-hidden rounded-xl bg-primary-soft", className)}
      >
        <RoomImage room={room} className="absolute inset-0 transition-transform duration-500 group-hover:scale-105" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent" />
        <div className="absolute inset-x-0 bottom-0 p-5 text-white">
          <h3 className="text-lg font-semibold">{room.name}</h3>
          <p className="text-[13px] text-white/80">
            {room.buildingName}, {room.typeName}
          </p>
          <p className="mt-1 text-sm font-semibold">{price}</p>
        </div>
      </Link>
    );
  }

  return (
    <Card className={className}>
      <div className="relative aspect-[4/3] bg-primary-soft">
        <RoomImage room={room} className="absolute inset-0" />
      </div>
      <div className="flex flex-col gap-3 p-4">
        <div>
          <h3 className="text-lg font-semibold">{room.name}</h3>
          <p className="text-[13px] text-text-secondary">
            {room.buildingName}, {room.typeName}
          </p>
        </div>
        <p className="flex items-center gap-1.5 text-[13px] text-text-secondary">
          <Users className="size-4" aria-hidden /> Up to {room.capacity} people
        </p>
        <p className="font-semibold">{price}</p>
        <Link to={`/rooms/${room.slug}`}>
          <Button size="sm" className="w-full">View details</Button>
        </Link>
      </div>
    </Card>
  );
}
